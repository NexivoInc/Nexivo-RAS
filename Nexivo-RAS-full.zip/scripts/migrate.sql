-- Run this in Neon / Supabase SQL editor

CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  email_verified BOOLEAN DEFAULT false,
  verification_code TEXT,
  verification_expires TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS devices (
  id SERIAL PRIMARY KEY,
  agent_id TEXT NOT NULL,
  name TEXT,
  ip TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS agent_heartbeats (
  agent_id TEXT PRIMARY KEY,
  ip TEXT,
  os TEXT,
  version TEXT,
  last_seen TIMESTAMP DEFAULT NOW()
);
